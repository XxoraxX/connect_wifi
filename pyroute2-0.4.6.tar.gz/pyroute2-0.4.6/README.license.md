Pyroute2 package is dual licensed since 0.3.6, emerging two licenses:

* GPL v2+
* Apache v2

It means, that being writing some derived code, or including the
library into distribution, you are free to choose the license from the
list above.

Apache v2 license was included to make the code compatible with the
OpenStack project.
