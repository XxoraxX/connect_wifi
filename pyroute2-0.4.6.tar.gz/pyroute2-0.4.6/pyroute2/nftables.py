'''
'''
from pyroute2.netlink.nfnetlink.nftables import NFTSocket


class NFTables(NFTSocket):
    pass
